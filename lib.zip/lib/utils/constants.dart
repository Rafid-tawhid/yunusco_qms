import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

TextStyle customTextStyle(double size, Color color, FontWeight weight) =>
    GoogleFonts.inter(fontSize: size, color: color, fontWeight: weight);

class AppConstants {
  // 🔗 API Base URLs //static const String baseUrl = "http://192.168.15.6:8090/";
  static const String baseUrl = "http://202.74.243.118:8090/";
  static const String versionNumber =
      "17.07.29"; // static const String baseUrl = "http://202.74.243.118:1726/"; //live
  static const String loginUrl = "api/LoginApi/GetUserLogin";
  static String token = ''; // 📱 Screen Dimensions
  static const int screenWidth = 428;
  static const int screenHeight = 926;
  static const int screenRegWidth = 428;
  static const int screenRegHeight = 841; // 📝 Text Styles
  static TextStyle title = GoogleFonts.inter(
    fontSize: 16,
    color: Colors.black,
    fontWeight: FontWeight.w700,
  );
  static TextStyle sub_title = GoogleFonts.inter(
    fontSize: 14,
    color: Colors.black,
    fontWeight: FontWeight.w500,
  );
  static TextStyle body = GoogleFonts.inter(
    fontSize: 14,
    color: Colors.black,
    fontWeight: FontWeight.w400,
  ); // ℹ️ Dynamic Text Style Function
  static TextStyle customTextStyle(
    double size,
    Color color,
    FontWeight weight,
  ) => GoogleFonts.inter(fontSize: size, color: color, fontWeight: weight);
  static TextStyle customNormalStyle(
    double? size,
    Color? color,
    FontWeight? weight,
  ) => GoogleFonts.inter(
    fontSize: size ?? 14,
    color: color ?? Colors.black,
    fontWeight: weight ?? FontWeight.normal,
  );
}

class myColors {
  static const primaryColor = Color(0xff161a49);
  static const blackMain = Color(0xff33363d);
  static const blackSecond = Color(0xff4d4f56);
}

class CheckedStatus {
  static String pass = '1';
  static String alter = '2';
  static String alter_check = '3';
  static String reject = '4';
}
